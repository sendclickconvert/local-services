// CRST SEO Monitoring - n8n on Replit
// This file starts the n8n workflow automation engine

const { exec } = require('child_process');
const http = require('http');

console.log('🚀 Starting CRST SEO Monitor (n8n)...');

// Keep-alive server for Replit (prevents sleep)
const server = http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/html' });
  res.end(`
    <!DOCTYPE html>
    <html>
      <head>
        <title>CRST SEO Monitor - n8n</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: #f5f5f5;
          }
          .container {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
          }
          h1 { color: #333; }
          .status { 
            display: inline-block;
            padding: 5px 15px;
            background: #4CAF50;
            color: white;
            border-radius: 4px;
            margin: 10px 0;
          }
          a {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background: #2196F3;
            color: white;
            text-decoration: none;
            border-radius: 4px;
          }
          a:hover { background: #0b7dda; }
        </style>
      </head>
      <body>
        <div class="container">
          <h1>🎯 CRST SEO Health Monitor</h1>
          <div class="status">● Running</div>
          
          <p>Your n8n automation is running and monitoring CRST service pages.</p>
          
          <h3>📊 Monitoring:</h3>
          <ul>
            <li>9 CRST service pages</li>
            <li>Daily checks at 9:00 AM</li>
            <li>Automated email alerts</li>
            <li>Google Sheets updates</li>
          </ul>
          
          <h3>⚙️ Access n8n:</h3>
          <a href="/webhook-test/ping" target="_blank">Open n8n Dashboard →</a>
          
          <p style="margin-top: 30px; color: #666; font-size: 0.9em;">
            Running on Replit | Powered by n8n
          </p>
        </div>
      </body>
    </html>
  `);
});

// Start keep-alive server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`✅ Keep-alive server running on port ${PORT}`);
  console.log(`🌐 Access at: ${process.env.REPL_SLUG}.${process.env.REPL_OWNER}.repl.co`);
});

// Start n8n
console.log('⚙️ Starting n8n workflow engine...');

const n8nProcess = exec('npx n8n start', (error, stdout, stderr) => {
  if (error) {
    console.error(`❌ Error starting n8n: ${error.message}`);
    return;
  }
  if (stderr) {
    console.error(`⚠️ n8n stderr: ${stderr}`);
  }
  console.log(`n8n output: ${stdout}`);
});

// Forward n8n output to console
n8nProcess.stdout.on('data', (data) => {
  console.log(`n8n: ${data}`);
});

n8nProcess.stderr.on('data', (data) => {
  console.error(`n8n error: ${data}`);
});

// Handle graceful shutdown
process.on('SIGTERM', () => {
  console.log('🛑 Shutting down...');
  n8nProcess.kill();
  server.close();
  process.exit(0);
});

console.log('✅ CRST SEO Monitor initialized');
console.log('📧 Email alerts configured');
console.log('📊 Google Sheets integration ready');
console.log('⏰ Daily schedule active');
